//DRY : Don't Repeat your self
const sql=require('./db');

exports.getAll=function(){
   return new Promise(resolve=>{
        let command="SELECT * FROM users";
        sql.query(command,(err, rows, fields)=>{
            resolve(rows);
        })
    }) 
};


exports.getById=function(id){
    return new Promise(resolve=>{
         let command="SELECT * FROM users  WHERE id="+id;
         sql.query(command,(err, rows, fields)=>{
             resolve(rows);
         })
     }) 
 };

 

 exports.insert=function(req){
    return new Promise(resolve=>{
        let firstname=req.body.firstname;
        console.log(firstname)
        let lastname=req.body.lastname;
        let location=req.body.location;
        let email=req.body.email;
        let password=req.body.password;
        console.log(email)
        let command=`INSERT INTO users(firstname,lastname,email,password) VALUES ("${firstname}","${lastname}","${email}","${password}",NOW())`;
        sql.query(command,(err, rows, fields)=>{
            resolve(rows);
        })
})
}

exports.remove=function(id){
    return new Promise(resolve=>{
        let command="DELETE FROM tasks Where id="+id ;
        sql.query(command,(err, rows, fields)=>{
            resolve(rows);
        })
})
}
